package com.example.examtest2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;

public class RedactCreate extends AppCompatActivity {

    EditText titleChangeTv;
    Button saveBtn;
    ProductList mainList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_redact_create);

        titleChangeTv = findViewById(R.id.titleChangeEt);
        saveBtn = findViewById(R.id.saveBtn);

        File file = getFileStreamPath("products.json");
        mainList = JsonUtil.readFromFile(file);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (titleChangeTv.getText().toString().isEmpty())
                    return;

                Product newProduct = new Product(titleChangeTv.getText().toString());
                mainList.getMainList().add(newProduct);
                JsonUtil.writeToJson(file, mainList);

                Intent in = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(in);
            }
        });

        Product product = (Product) getIntent().getSerializableExtra("product");
        if (product != null){
            titleChangeTv.setText(product.getTitle());

            saveBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (titleChangeTv.getText().toString().isEmpty())
                        return;

                    mainList.getMainList().removeIf(p -> p.getTitle().trim().equals(product.getTitle().trim()));

                    product.setTitle(titleChangeTv.getText().toString());
                    mainList.getMainList().add(product);
                    JsonUtil.writeToJson(file, mainList);

                    Intent in = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(in);
                }
            });
        }

    }
}
