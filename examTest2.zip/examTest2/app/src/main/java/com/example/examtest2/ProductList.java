package com.example.examtest2;

import java.util.ArrayList;

public class ProductList {

    private ArrayList<Product> mainList;

    public ProductList(ArrayList<Product> list){
        this.mainList = list;
    }

    public ProductList(){
        this.mainList = new ArrayList<Product>();
    }

    public ArrayList<Product> getMainList(){
        return  mainList;
    }

    public void setMainList(ArrayList<Product> value){
        this.mainList = value;
    }
}
