package com.example.examtest2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;

public class MainAdapter extends BaseAdapter {

    Context context;
    ProductList mainList;
    LayoutInflater inflater;

    public MainAdapter(Context context, ProductList list){
        this.context = context;
        this.mainList = list;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mainList.getMainList().size();
    }

    @Override
    public Object getItem(int i) {
        return mainList.getMainList().get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    @SuppressLint({"ViewHolder", "InflateParams", "UseSwitchCompatOrMaterialCode"})
    public View getView(int i, View view, ViewGroup viewGroup) {

        View mainView = inflater.inflate(R.layout.item_product, null);
        TextView titleTv = mainView.findViewById(R.id.titleTv);
        Switch isPurchasedSwt = mainView.findViewById(R.id.isPurchasedSwt);
        Button redactBtn = mainView.findViewById(R.id.redactBtn);
        Button deleteBtn = mainView.findViewById(R.id.deleteBtn);

        Product currentProduct = mainList.getMainList().get(i);

        titleTv.setText(currentProduct.getTitle());

        isPurchasedSwt.setChecked(currentProduct.getStatus());
        isPurchasedSwt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                currentProduct.setStatus(b);
            }
        });

        isPurchasedSwt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

            }
        });

        redactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(context, RedactCreate.class);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                in.putExtra("product", currentProduct);
                context.startActivity(in);
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainList.getMainList().remove(currentProduct);
                notifyDataSetChanged();

            }
        });

        return mainView;
    }
}