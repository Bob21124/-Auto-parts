package com.example.examtest2;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class JsonUtil {
    static Gson gson = new Gson();

    public static ProductList readFromFile(File file){
        try(FileReader reader = new FileReader(file)){
            return gson.fromJson(reader, ProductList.class);
        }
        catch (Exception ignored) {
            return new ProductList();
        }
    }

    public static void writeToJson(File file, ProductList list){
        try(FileWriter writer = new FileWriter(file)){
            gson.toJson(list, writer);
        }
        catch (Exception ignored) {

        }
    }
}