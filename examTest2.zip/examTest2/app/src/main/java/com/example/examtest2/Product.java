package com.example.examtest2;

import java.io.Serializable;

public class Product implements Serializable {

    private String title;
    private boolean isPurchased;

    public Product(String title){
        this.title = title;
        this.isPurchased = false;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String value){
        title = value;
    }

    public boolean getStatus(){
        return isPurchased;
    }

    public void setStatus(boolean value){
        isPurchased = value;
    }
}
