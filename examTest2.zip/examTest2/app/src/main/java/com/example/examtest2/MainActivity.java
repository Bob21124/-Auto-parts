package com.example.examtest2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    Button createBtn;
    ListView mainLv;
    ProductList productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        createBtn = findViewById(R.id.createBtn);
        mainLv = findViewById(R.id.mainLv);

        File file = getFileStreamPath("products.json");
        productList = JsonUtil.readFromFile(file);

        MainAdapter adapter = new MainAdapter(getApplicationContext(), productList);
        mainLv.setAdapter(adapter);



        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(getApplicationContext(), RedactCreate.class);
                startActivity(in);
            }
        });
    }
}
